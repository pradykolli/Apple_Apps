//
//  Guesser.swift
//  Guesser
//
//  Created by Pradeep Kolli on 2/26/19.
//  Copyright © 2019 student. All rights reserved.
//

import Foundation

class Guesser {
    private init() {}
    static let shared = Guesser()
    private var correctAnswer:Int = 0  //, the current correct answer
    private var _numAttempts:Int  = 0 //, the number of attempts the user has made thus far to guess
    private var guesses:[Guess]  = [] //guesses, an array of Guess structs

    
    public var numAttempts:Int{
        get{
            return Guesser.shared._numAttempts
        }
    }
    
    func createNewProblem(){
        correctAnswer = Int.random(in: 0...10)
        _numAttempts = 0
    }
    
    enum Result:String {case tooLow = "Too Low", tooHigh = "Too High", correct = "Correct"}
    
    func amIRight(guess:Int) -> Result{
        
        if(guess == correctAnswer){
            guesses.append(Guess(correctAnswer: correctAnswer, numAttemptsRequired: _numAttempts))
            return Result.correct
        }
        else if(guess < correctAnswer){
            _numAttempts = _numAttempts + 1
            return Result.tooLow
        }
        else{
            _numAttempts = _numAttempts + 1
            return Result.tooHigh
        }
    }
    func guess(_ index:Int) -> Guess{
        return guesses[index]
    }
    subscript(guess:Int) -> Guess{
        return guesses[guess]
    }
    func numGuesses() -> Int{
        return guesses.count
    }
    func clearStatistics(){
        guesses = []
    }
    func minimumNumAttempts() ->Int{
        var min:Guess
        if numGuesses() != 0{
             min = guesses[0]
        }
        else{
            return 0
        }
        for i in 0..<guesses.count{
            if (guesses[i].numAttemptsRequired < min.numAttemptsRequired){
                min = guesses[i]
            }
        }
        return min.numAttemptsRequired
    }
    func maximumNumAttempts() -> Int{
        var max:Guess
        if numGuesses() != 0{
            max = guesses[0]
        }
        else{
            return 0
        }
        for i in 0..<guesses.count{
            if (guesses[i].numAttemptsRequired > max.numAttemptsRequired){
                max = guesses[i]
            }
        }
        return max.numAttemptsRequired
    }
    
    func mean() -> Double{
        if numGuesses() == 0{
            return 0
        }
        var numValue = 0
        for i in guesses{
            numValue += i.numAttemptsRequired
        }
        return Double(numValue/numGuesses())
    }
    
    func standardDeviation() -> Double{
        if numGuesses() == 0{
            return 0
        }
        var sum:Double = 0
        for i in guesses{
            sum += (mean() - Double(i.numAttemptsRequired)) * (mean() - Double(i.numAttemptsRequired))
        }
        return sqrt(Double(sum))
    }
}


struct Guess {
    var correctAnswer:Int
    var numAttemptsRequired:Int
}
