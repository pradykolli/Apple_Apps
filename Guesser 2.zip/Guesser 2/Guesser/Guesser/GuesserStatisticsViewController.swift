//
//  GuesserStatisticsViewController.swift
//  Guesser
//
//  Created by Pradeep Kolli on 2/26/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class GuesserStatisticsViewController: UIViewController {

    @IBOutlet weak var stdDevLBL: UILabel!
    @IBOutlet weak var meanLBL: UILabel!
    @IBOutlet weak var maxLBL: UILabel!
    @IBOutlet weak var minLBL: UILabel!
    
    @IBOutlet weak var clearStatsBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        clearStatsBtn.layer.cornerRadius = 5
        loadValues()
    }
    override func viewWillAppear(_ animated: Bool) {
        loadValues()
    }
    func loadValues(){
        stdDevLBL.text = String(Guesser.shared.standardDeviation())
        meanLBL.text = String(Guesser.shared.mean())
        maxLBL.text = String(Guesser.shared.maximumNumAttempts())
        minLBL.text = String(Guesser.shared.minimumNumAttempts())
    }
    func reset(){
        stdDevLBL.text = "0"
        meanLBL.text = "0"
        maxLBL.text = "0"
        minLBL.text = "0"
    }
    @IBAction func clearActionBTN(_ sender: Any) {
        Guesser.shared.clearStatistics()
        reset()
    }
}
