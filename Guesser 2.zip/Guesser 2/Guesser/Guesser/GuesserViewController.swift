//
//  GuesserViewController.swift
//  Guesser
//
//  Created by Pradeep kolli on 2/26/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class GuesserViewController: UIViewController {

    @IBOutlet weak var myGuessTF: UITextField!
    @IBOutlet weak var suggestionLBL: UILabel!
    @IBOutlet weak var amIRightBtn: UIButton!
    @IBOutlet weak var createNewProblemBtn: UIButton!
    
    @IBAction func amIRightActionBTN(_ sender: Any) {
        let amIRight = Guesser.shared.amIRight(guess: Int(myGuessTF.text!) ?? 0)
        if amIRight.rawValue == "Correct"{
            displayMessage()
            Guesser.shared.createNewProblem()
            suggestionLBL.text? = "Correct"
        }
        else if amIRight.rawValue == "Too Low"{
            suggestionLBL.text? = "Too Low"
        }
        else{
            suggestionLBL.text? = "Too High"
        }
    }
    
    @IBAction func createNewProblemActionBTN(_ sender: Any) {
        suggestionLBL.text = "Try on buddy"
        myGuessTF.text = ""
        Guesser.shared.createNewProblem()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        amIRightBtn.layer.cornerRadius = 5
        createNewProblemBtn.layer.cornerRadius = 5
    }

    func displayMessage(){
        let alert = UIAlertController(title: "Well done",
            message: "You got it in \(Guesser.shared.numAttempts) tries",
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Re-Guess", style: .default,
                                      handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

