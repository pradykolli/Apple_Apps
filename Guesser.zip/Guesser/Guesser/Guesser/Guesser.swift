//
//  Guesser.swift
//  Guesser
//
//  Created by student on 2/26/19.
//  Copyright © 2019 student. All rights reserved.
//

import UIKit

class Guesser: UIViewController {
    private var correctAnswer:Int   //, the current correct answer
    private var _numAttempts:Int = 0   //, the number of attempts the user has made thus far to guess
    private var guesses:[Guess] = []   //guesses, an array of Guess structs
    struct Guess {
        var correctAnswer:Int
        var numAttemptsRequired:Int
    }
    
    var numAttempts                 //, a read-only stored property based on numAttempts
    public var shared = Guesser()
    
    func createNewProblem(){
        correctAnswer = Int.random(in: 0...10)
        _numAttempts = 0
    }
    
    enum Result:String {case tooLow = "Too Low", tooHigh = "Too High", correct = "Correct"}
    
    func amIRight(guess:Int) -> Result{
        _numAttempts += 1
        if(guess == correctAnswer){
            guesses.append(Guess(correctAnswer: correctAnswer, numAttemptsRequired: _numAttempts))
            displayMessage()
            createNewProblem()
            return Result.correct
        }
        else if(guess < correctAnswer){
            return Result.tooLow
        }
        else{
            return Result.tooHigh
        }
    }
    func guess(index:Int){
        
    }
    func numGuesses() -> Int{
        return guesses.count
    }
    func clearStatistics(){
        guesses = []
    }
    func minimumNumAttempts(){
        var min = guesses[0]
        for i in range(0 ..< guesses.count){
            if (guesses[i])
        }
    }
    func maximumNumAttempts(){}
    func displayMessage(){
        let alert = UIAlertController(title: "Well done",
                                      message: "You got it in \(Guesser.shared.numAttempts) tries",
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default,
                                      handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
